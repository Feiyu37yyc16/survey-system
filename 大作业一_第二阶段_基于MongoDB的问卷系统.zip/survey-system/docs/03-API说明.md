# 03 API 说明

接口统一返回 JSON：

```json
{ "code": 0, "data": { ... } }        // 成功
{ "code": 1, "message": "错误信息" }  // 失败
```

HTTP 状态码：200 成功；400 参数或业务校验失败；401 未登录；404 资源不存在。

会话通过 Cookie 维持：注册或登录成功后服务端写入签名 Cookie，后续请求自动携带。同一问卷的"只能看到自己创建的问卷"在服务端按会话中的用户 ID 校验。

## 1. 认证接口

### 1.1 注册

`POST /api/register`

请求：

```json
{ "username": "alice", "password": "alice123" }
```

返回：

```json
{ "code": 0, "data": { "id": "668f...", "username": "alice" } }
```

校验：用户名 2-20 个字符且唯一；密码至少 6 位。注册成功后自动登录。

### 1.2 登录

`POST /api/login`

请求：

```json
{ "username": "alice", "password": "alice123" }
```

返回同上。用户名或密码错误返回 400。

### 1.3 退出

`POST /api/logout`，无参数，清空会话。

### 1.4 当前用户

`GET /api/me`，返回当前登录用户信息；未登录返回 401。

## 2. 问卷接口（需登录，仅本人问卷）

### 2.1 创建问卷

`POST /api/surveys`

请求：

```json
{ "title": "未命名问卷", "description": "", "allow_anonymous": false, "allow_multi_submit": false, "deadline": null }
```

返回新建的问卷对象，初始状态为 `draft`，并生成 `url_code` 短码。

### 2.2 问卷列表

`GET /api/surveys`

返回当前用户所有问卷，按更新时间倒序。

### 2.3 问卷详情

`GET /api/surveys/<id>`

返回问卷全部字段，包括题目数组和跳转规则。非本人问卷返回 404。

### 2.4 更新问卷（保存编辑）

`PUT /api/surveys/<id>`

请求：

```json
{
  "title": "用户满意度调查",
  "description": "感谢参与",
  "allow_anonymous": false,
  "allow_multi_submit": false,
  "deadline": "2026-12-31T23:59",
  "questions": [
    {
      "qid": "q1",
      "type": "single",
      "title": "你的性别",
      "required": true,
      "options": ["男", "女", "其他"],
      "jump_rules": [ { "condition": { "op": "eq", "value": "女" }, "target": "q3" } ]
    }
  ]
}
```

服务端校验：题型合法、选项非空且不重复、多选数量限制合法、文本字数限制合法、数值范围合法、跳转目标存在且在本题之后。校验失败返回 400 和具体错误位置（第几题）。只有 `draft` 状态的问卷可以编辑。

### 2.5 发布问卷

`POST /api/surveys/<id>/publish`

要求问卷至少有一道题。发布后状态变为 `published`，可以填写。

### 2.6 关闭问卷

`POST /api/surveys/<id>/close`

状态变为 `closed`，之后不可填写。

## 3. 填写接口

### 3.1 获取问卷（链接入口）

`GET /api/surveys/code/<url_code>`

返回标题、说明、是否匿名、题目列表（含各题限制条件，不含跳转规则之外的信息）。

状态检查：问卷必须是 `published` 且未过截止时间，否则 404；问卷不允许匿名填写时，未登录用户返回 401。

### 3.2 提交单题答案并获取下一题

`POST /api/respond/<url_code>/answer`

请求：

```json
{ "qid": "q1", "value": "女", "answered": ["q1"] }
```

`answered` 是本次填写中已经回答过的题目编号列表（不含当前题）。

处理流程：校验当前题答案是否符合规则 → 计算下一题（先看当前题有没有命中的跳转规则，命中则跳转目标，否则按顺序取下一道未回答的题）→ 返回：

```json
{ "code": 0, "data": { "next_qid": "q3" } }
```

没有下一题时 `next_qid` 为 null。校验失败返回 400 和错误信息。

### 3.3 提交整份问卷

`POST /api/respond/<url_code>/submit`

请求：

```json
{ "answers": [ { "qid": "q1", "value": "女" }, { "qid": "q3", "value": "教师" } ] }
```

服务端按题目顺序模拟一遍填写流程：检查每一道被访问到的题都有答案、答案合法、跳转路径一致，避免跳过前端直接提交非法数据。通过后保存一条 responses 记录。

限制：问卷不允许匿名时未登录用户不可提交；问卷未开启多次填写时，同一登录用户重复提交返回 400。

## 4. 统计接口（需登录，仅本人问卷）

### 4.1 整体统计

`GET /api/surveys/<id>/stats`

返回：

```json
{
  "code": 0,
  "data": {
    "total_submits": 2,
    "questions": {
      "q1": { "type": "single", "answered": 2, "options": [ { "value": "男", "count": 1 }, { "value": "女", "count": 1 } ] },
      "q2": { "type": "multi", "answered": 2, "options": [ { "value": "香蕉", "count": 1 }, { "value": "西瓜", "count": 1 } ] },
      "q3": { "type": "text", "answered": 2, "values": ["教师", "程序员"] },
      "q4": { "type": "number", "answered": 2, "avg": 20.0, "min": 15, "max": 25 }
    }
  }
}
```

说明：`total_submits` 是收到的填写总份数；`answered` 是实际回答了该题的人数；多选 `answered` 是所有被选择次数的合计；被跳过的题不出现在统计中（跳过意味着没回答）。

### 4.2 单题统计

`GET /api/surveys/<id>/stats/<qid>`

返回该题单独的统计，结构与整体统计中对应题目一致。

## 5. 题目库接口（第二阶段新增，需登录）

题目库接口按题目读写权限区分：owner（创建者）可修改、共享、恢复；其他用户只能读取共享题、克隆共享题、在问卷中引用共享题。私有题对其他用户不可见（404）。

### 5.1 创建题库题

`POST /api/questions`

请求（字段与问卷题目一致，不含 qid 和 jump_rules；跳转规则是问卷级配置，题库不保存）：

```json
{
  "type": "single",
  "title": "你的年龄",
  "required": true,
  "options": ["18岁以下", "18-30", "30岁以上"]
}
```

返回创建的题库题对象（含 `id`、`current_version=1`、`versions` 数组）。

### 5.2 题库列表

`GET /api/questions?scope=mine|shared|all`

- `mine`（默认）：我创建的题目
- `shared`：其他用户共享的题目
- `all`：我的 + 共享的

每项返回 `id`、`display_title`、`owner_name`、`mine`、`shared`、`current_version`、`versions`（含每个版本的 `content`）、`source_question_id`（克隆来源）。

### 5.3 题库题详情（含版本历史）

`GET /api/questions/<id>`

返回完整 `versions` 数组，每个版本含 `version`、`source_version`（由哪个版本改来）、`created_at`、`content`。

### 5.4 修改题库题（生成新版本）

`PUT /api/questions/<id>`

请求内容同创建接口。不覆盖原版本，而是追加一个新版本（`current_version` 递增，新版本 `source_version` 指向旧版本号）。已发布问卷中引用的旧版本快照不受影响。

### 5.5 恢复旧版本

`POST /api/questions/<id>/revert`

```json
{ "version": 1 }
```

用 v1 的内容生成一个新版本（`source_version=1`），版本历史保留，可继续追溯到恢复来源。仅 owner。

### 5.6 克隆共享题到我的题库

`POST /api/questions/<id>/clone`

任何登录用户可克隆自己可见（本人或共享）的题。生成的新题 `mine=true`、`current_version=1`、`source_question_id` 指向原题，之后独立修改，不影响原题。

### 5.7 共享 / 取消共享

`POST /api/questions/<id>/share`

```json
{ "shared": true }
```

仅 owner。共享后所有登录用户可读取、克隆、在问卷中引用。

### 5.8 查看题目被哪些问卷使用

`GET /api/questions/<id>/usage`

返回使用该题的问卷列表：

```json
{
  "code": 0,
  "data": [
    { "survey_id": "...", "title": "用户调查一", "status": "published", "qid": "a1", "bank_version": 3 }
  ]
}
```

### 5.9 跨问卷单题统计

`GET /api/questions/<id>/stats`

汇总所有引用了该题库题的问卷中这道题的作答（跨问卷、跨版本聚合）：

```json
{
  "code": 0,
  "data": {
    "answered": 5,
    "usage_count": 2,
    "surveys": [ { "survey_id": "...", "title": "...", "qid": "a1", "bank_version": 3 } ],
    "result": { "type": "single", "answered": 5, "options": [ { "value": "18-30", "count": 3 }, { "value": "30岁以上", "count": 2 } ] }
  }
}
```

`result` 结构与问卷内单题统计一致（单选分组、多选展开、文本列表、数字聚合）。

### 5.10 问卷引用题库题

问卷更新接口 `PUT /api/surveys/<id>` 的 `questions` 数组中，来自题库的题目按如下格式提交：

```json
{
  "qid": "a1",
  "source_type": "bank",
  "bank_question_id": "题库题ID",
  "bank_version": 3,
  "jump_rules": []
}
```

服务端校验：题库题存在、对当前用户可见（本人或共享）、版本号存在于该题版本列表；校验通过后**以题库题该版本的内容生成问卷内快照**（客户端传的 title/options 等字段不信任，以后端版本内容为准）。不传 `source_type` 的旧格式题目按本问卷自建题目处理，第一阶段数据完全兼容。
