import os
os.environ['MONGO_DB'] = 'survey_system_test2'

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'server'))

from bson import ObjectId
from app import app
from db import db, question_bank

client_a = app.test_client()
client_b = app.test_client()

RESULTS = []

BANK_ID = None
S1_ID = None
S1_CODE = None
S1_QID = None
S2_ID = None
S2_CODE = None
S2_QID = None


def post(client, path, body):
    return client.open(path, method='POST', json=body)


def put(client, path, body):
    return client.open(path, method='PUT', json=body)


def get(client, path):
    return client.open(path, method='GET')


def body(resp):
    return resp.get_json()


def record(name, ok, input_desc, expect, actual):
    RESULTS.append({
        'name': name,
        'ok': ok,
        'input': input_desc,
        'expect': expect,
        'actual': actual,
    })
    print('[%s] %s' % ('PASS' if ok else 'FAIL', name))


def register_user(client, username, password):
    return post(client, '/api/register', {'username': username, 'password': password}).status_code


def create_draft(client, title, questions):
    resp = post(client, '/api/surveys', {'title': title})
    sid = body(resp)['data']['id']
    put(client, '/api/surveys/' + sid, {
        'title': title, 'description': '', 'allow_anonymous': False,
        'allow_multi_submit': False, 'deadline': None, 'questions': questions,
    })
    return sid


def publish(client, sid):
    post(client, '/api/surveys/' + sid + '/publish', None)


def bank_question(type_, title, **kw):
    payload = {'type': type_, 'title': title, 'required': True}
    if type_ in ('single', 'multi'):
        payload['options'] = ['A', 'B', 'C']
    payload.update(kw)
    return payload


class TestQuestionBank(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        db.client.drop_database('survey_system_test2')
        register_user(client_a, 'alice', 'alice123')
        register_user(client_b, 'bob', 'bob123456')

    def test_01_create_bank_question(self):
        global BANK_ID
        resp = post(client_a, '/api/questions', bank_question('single', '你的年龄'))
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['current_version'] == 1 \
            and len(data['data']['versions']) == 1 and data['data']['shared'] is False
        record('创建题库题生成 v1', ok, 'POST /api/questions 单选题"你的年龄"', 'current_version=1，版本数组长度1', data.get('data'))
        BANK_ID = data['data']['id']

    def test_02_invalid_bank_question(self):
        resp = post(client_a, '/api/questions', {'type': 'single', 'title': '', 'options': ['A', 'B']})
        data = body(resp)
        ok = resp.status_code == 400 and data['code'] == 1
        record('空标题题库题被拒绝', ok, 'POST /api/questions title=空', '报错：题目类型和标题不能为空', data.get('message'))

        resp = post(client_a, '/api/questions', {'type': 'single', 'title': '重复选项', 'options': ['A', 'A']})
        data = body(resp)
        ok = resp.status_code == 400 and data['code'] == 1
        record('重复选项题库题被拒绝', ok, 'POST /api/questions options=[A,A]', '报错：选项不能重复', data.get('message'))

    def test_03_update_creates_new_version(self):
        resp = put(client_a, '/api/questions/' + BANK_ID, bank_question('single', '你的年龄', required=False))
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['current_version'] == 2 \
            and len(data['data']['versions']) == 2 \
            and data['data']['versions'][1]['source_version'] == 1
        record('修改题库题生成 v2 并记录来源', ok, 'PUT /api/questions 修改为"你的年龄"(非必答)', 'current_version=2，v2.source_version=1', data.get('data'))

    def test_04_revert_to_old_version(self):
        resp = post(client_a, '/api/questions/' + BANK_ID + '/revert', {'version': 1})
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['current_version'] == 3 \
            and len(data['data']['versions']) == 3 \
            and data['data']['versions'][2]['source_version'] == 1 \
            and data['data']['versions'][2]['content']['required'] is True
        record('恢复到 v1 内容生成 v3', ok, 'POST /api/questions/revert version=1', 'current_version=3，v3.source_version=1，v3 内容为必答', data.get('data'))

    def test_05_permission_control(self):
        resp = get(client_b, '/api/questions/' + BANK_ID)
        data = body(resp)
        ok = resp.status_code == 404 and data['code'] == 1
        record('其他用户不可见私有题库题', ok, 'bob GET /api/questions/<alice题>', '报错：题目不存在或无权访问', data.get('message'))

        resp = put(client_b, '/api/questions/' + BANK_ID, bank_question('single', '篡改'))
        data = body(resp)
        ok = resp.status_code == 404 and data['code'] == 1
        record('其他用户不可修改私有题库题', ok, 'bob PUT /api/questions/<alice题>', '报错：题目不存在或无权修改', data.get('message'))

    def test_06_share_and_clone(self):
        post(client_a, '/api/questions/' + BANK_ID + '/share', {'shared': True})
        resp = get(client_b, '/api/questions/' + BANK_ID)
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['shared'] is True and data['data']['mine'] is False
        record('共享后其他用户可读取', ok, 'alice 共享题目后 bob GET', 'bob 可读，shared=True，mine=False', data.get('data'))

        resp = post(client_b, '/api/questions/' + BANK_ID + '/clone', None)
        data = body(resp)
        new_id = data['data']['id']
        ok = resp.status_code == 200 and data['data']['mine'] is True \
            and data['data']['source_question_id'] == BANK_ID and data['data']['current_version'] == 1
        record('克隆共享题到自己的题库', ok, 'bob POST /api/questions/<共享题>/clone', '新题 mine=True，source_question_id=原题，v1', data.get('data'))

        put(client_b, '/api/questions/' + new_id, bank_question('single', 'B 的年龄'))
        resp = get(client_a, '/api/questions/' + BANK_ID)
        data = body(resp)
        ok = data['data']['display_title'] == '你的年龄'
        record('修改克隆题不影响原题', ok, 'bob 修改克隆题后 alice 查看原题', '原题标题仍为"你的年龄"', data.get('data').get('display_title'))

    def test_07_survey_use_bank_question(self):
        global S1_ID, S1_QID
        sid = create_draft(client_a, '用户调查一', [])
        S1_ID = sid
        questions = [{
            'qid': 'a1', 'source_type': 'bank', 'bank_question_id': BANK_ID,
            'bank_version': 3, 'type': 'single', 'title': '你的年龄',
            'required': True, 'options': ['A', 'B', 'C'], 'jump_rules': [],
        }]
        resp = put(client_a, '/api/surveys/' + sid, {
            'title': '用户调查一', 'description': '', 'allow_anonymous': False,
            'allow_multi_submit': False, 'deadline': None, 'questions': questions,
        })
        data = body(resp)
        S1_QID = data['data']['questions'][0]['qid']
        ok = resp.status_code == 200 and data['data']['questions'][0]['source_type'] == 'bank' \
            and data['data']['questions'][0]['bank_question_id'] == BANK_ID \
            and data['data']['questions'][0]['bank_version'] == 3
        record('问卷引用题库题保存为快照', ok, 'PUT /api/surveys 引用题库题 v3', '题目带 source_type=bank、bank_question_id、bank_version=3', data.get('data').get('questions'))

        resp = get(client_a, '/api/questions/' + BANK_ID + '/usage')
        data = body(resp)
        ok = resp.status_code == 200 and len(data['data']) == 1 and data['data'][0]['survey_id'] == S1_ID
        record('查看题目被哪些问卷使用', ok, 'GET /api/questions/<id>/usage', '返回使用该题的问卷列表', data.get('data'))

    def test_08_bad_bank_ref_rejected(self):
        resp = put(client_a, '/api/surveys/' + S1_ID, {
            'title': '用户调查一', 'description': '', 'allow_anonymous': False,
            'allow_multi_submit': False, 'deadline': None,
            'questions': [{
                'qid': 'a1', 'source_type': 'bank', 'bank_question_id': '000000000000000000000000',
                'bank_version': 1, 'type': 'single', 'title': '不存在', 'required': True,
                'options': ['A', 'B'], 'jump_rules': [],
            }],
        })
        data = body(resp)
        ok = resp.status_code == 400 and data['code'] == 1
        record('引用不存在的题库题被拒绝', ok, 'PUT 引用无效题库题ID', '报错：题库题不存在', data.get('message'))

        post(client_a, '/api/questions/' + BANK_ID + '/share', {'shared': False})
        resp = put(client_b, '/api/surveys/' + create_draft(client_b, 'bob 问卷', []), {
            'title': 'bob 问卷', 'description': '', 'allow_anonymous': False,
            'allow_multi_submit': False, 'deadline': None,
            'questions': [{
                'qid': 'b1', 'source_type': 'bank', 'bank_question_id': BANK_ID,
                'bank_version': 3, 'type': 'single', 'title': '你的年龄',
                'required': True, 'options': ['A', 'B', 'C'], 'jump_rules': [],
            }],
        })
        data = body(resp)
        ok = resp.status_code == 400 and data['code'] == 1
        record('引用未共享的题库题被拒绝', ok, 'bob 在问卷中引用 alice 私有题', '报错：题库题不可用（未共享）', data.get('message'))

    def test_09_snapshot_isolation_after_publish(self):
        post(client_a, '/api/questions/' + BANK_ID + '/share', {'shared': True})
        publish(client_a, S1_ID)
        put(client_a, '/api/questions/' + BANK_ID, bank_question('single', '你的年龄(新版)'))
        resp = get(client_a, '/api/surveys/' + S1_ID)
        data = body(resp)
        q = data['data']['questions'][0]
        ok = q['title'] == '你的年龄' and q['bank_version'] == 3
        record('已发布问卷不受题库改题影响', ok, '发布问卷后修改题库题生成新版本', '问卷内题目仍为旧版本标题和版本号', q)

    def test_10_legacy_question_compat(self):
        sid = create_draft(client_a, '老问卷', [
            {'qid': 'q1', 'type': 'single', 'title': '老题', 'required': True, 'options': ['A', 'B'], 'jump_rules': []}
        ])
        publish(client_a, sid)
        resp = post(client_a, '/api/respond/' + body(get(client_a, '/api/surveys/' + sid))['data']['url_code'] + '/submit',
                    {'answers': [{'qid': 'q1', 'value': 'A'}]})
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['id']
        record('第一阶段老题目仍可正常填写', ok, '无 source_type 的老问卷题目提交答案', '提交成功返回 id', data.get('data'))

    def test_11_cross_survey_single_question_stats(self):
        global S2_ID, S2_QID
        questions2 = [{
            'qid': 'c1', 'source_type': 'bank', 'bank_question_id': BANK_ID,
            'bank_version': 4, 'type': 'single', 'title': '你的年龄(新版)',
            'required': True, 'options': ['A', 'B', 'C'], 'jump_rules': [],
        }]
        sid = create_draft(client_a, '用户调查二', questions2)
        S2_ID = sid
        S2_QID = 'c1'
        publish(client_a, sid)

        post(client_a, '/api/respond/' + body(get(client_a, '/api/surveys/' + S1_ID))['data']['url_code'] + '/submit',
             {'answers': [{'qid': S1_QID, 'value': 'A'}]})
        post(client_a, '/api/respond/' + body(get(client_a, '/api/surveys/' + S2_ID))['data']['url_code'] + '/submit',
             {'answers': [{'qid': S2_QID, 'value': 'B'}]})

        resp = get(client_a, '/api/questions/' + BANK_ID + '/stats')
        data = body(resp)
        r = data['data']
        opt_map = {o['value']: o['count'] for o in r['result']['options']}
        ok = resp.status_code == 200 and r['usage_count'] == 2 and r['answered'] == 2 \
            and opt_map.get('A') == 1 and opt_map.get('B') == 1
        record('跨问卷单题统计汇总所有问卷回答', ok, '两份问卷引用同题不同版本并各填一条', 'usage_count=2，answered=2，A=1、B=1', r)


def main():
    unittest.main(exit=False)
    report_path = Path(__file__).resolve().parent / '测试报告_自动化_阶段二.md'
    lines = ['# 自动化测试报告（第二阶段：题目库）', '', '运行时间：见下方用例顺序', '', '| 用例 | 结果 | 输入 | 期望输出 | 实际输出 |', '|---|---|---|---|---|']
    for r in RESULTS:
        lines.append('| %s | %s | %s | %s | %s |' % (r['name'], '通过' if r['ok'] else '失败', r['input'], r['expect'], r['actual']))
    passed = sum(1 for r in RESULTS if r['ok'])
    lines.append('')
    lines.append('共 %d 个用例，通过 %d 个，失败 %d 个。' % (len(RESULTS), passed, len(RESULTS) - passed))
    report_path.write_text('\n'.join(lines), encoding='utf-8')
    print('测试报告已写入：%s' % report_path)
    if passed < len(RESULTS):
        sys.exit(1)


if __name__ == '__main__':
    main()
