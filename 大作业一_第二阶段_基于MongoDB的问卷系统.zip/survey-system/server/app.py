import random
import string
from datetime import datetime
from flask import Flask, jsonify, request, session, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId
from config import SECRET_KEY, URL_CODE_LEN
from db import db, users, surveys, responses, question_bank, init_db
import logic

app = Flask(__name__, static_folder='static', static_url_path='/static')
app.secret_key = SECRET_KEY
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'


def ok(data=None):
    return jsonify({'code': 0, 'data': data})


def err(message, status=400):
    return jsonify({'code': 1, 'message': message}), status


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    try:
        return users.find_one({'_id': ObjectId(uid)})
    except Exception:
        return None


def parse_deadline(value):
    if not value:
        return None
    for fmt in ('%Y-%m-%dT%H:%M', '%Y-%m-%d %H:%M', '%Y-%m-%d'):
        try:
            return datetime.strptime(str(value), fmt)
        except ValueError:
            continue
    return None


def gen_url_code():
    chars = string.ascii_lowercase + string.digits
    for _ in range(50):
        code = ''.join(random.choice(chars) for _ in range(URL_CODE_LEN))
        if not surveys.find_one({'url_code': code}):
            return code
    raise RuntimeError('无法生成问卷短码')


def question_view(q):
    return {
        'qid': q.get('qid'),
        'type': q.get('type'),
        'title': q.get('title'),
        'required': q.get('required', False),
        'options': q.get('options', []),
        'min_choices': q.get('min_choices'),
        'max_choices': q.get('max_choices'),
        'exact_choices': q.get('exact_choices'),
        'min_length': q.get('min_length'),
        'max_length': q.get('max_length'),
        'min_value': q.get('min_value'),
        'max_value': q.get('max_value'),
        'integer_only': q.get('integer_only', False),
        'jump_rules': q.get('jump_rules', []),
        'source_type': q.get('source_type', 'own'),
        'bank_question_id': str(q['bank_question_id']) if q.get('bank_question_id') else None,
        'bank_version': q.get('bank_version'),
    }


def survey_view(doc):
    return {
        'id': str(doc['_id']),
        'title': doc.get('title'),
        'description': doc.get('description', ''),
        'allow_anonymous': doc.get('allow_anonymous', False),
        'allow_multi_submit': doc.get('allow_multi_submit', False),
        'status': doc.get('status'),
        'deadline': doc.get('deadline').strftime('%Y-%m-%dT%H:%M') if doc.get('deadline') else None,
        'url_code': doc.get('url_code'),
        'created_at': doc.get('created_at').strftime('%Y-%m-%d %H:%M') if doc.get('created_at') else None,
        'updated_at': doc.get('updated_at').strftime('%Y-%m-%d %H:%M') if doc.get('updated_at') else None,
        'published_at': doc.get('published_at').strftime('%Y-%m-%d %H:%M') if doc.get('published_at') else None,
        'questions': [question_view(q) for q in doc.get('questions', [])],
    }


def find_own_survey(sid, user):
    if not ObjectId.is_valid(sid):
        return None
    return surveys.find_one({'_id': ObjectId(sid), 'owner_id': user['_id']})


def find_published_survey(url_code):
    doc = surveys.find_one({'url_code': url_code})
    if not doc:
        return None
    if doc['status'] != 'published':
        return None
    if doc.get('deadline') and doc['deadline'] < datetime.utcnow():
        return None
    return doc


def survey_fill_view(doc):
    return {
        'id': str(doc['_id']),
        'title': doc.get('title'),
        'description': doc.get('description', ''),
        'allow_anonymous': doc.get('allow_anonymous', False),
        'questions': [question_view(q) for q in doc.get('questions', [])],
    }


def single_question_stats(oid, q):
    qid = q['qid']
    qtype = q['type']
    rows = list(responses.aggregate(logic.stats_pipeline({'survey_id': oid, 'answers.qid': qid}, qtype)))
    if qtype == 'single':
        total = sum(r['count'] for r in rows)
        return {'type': qtype, 'answered': total, 'options': [{'value': r['_id'], 'count': r['count']} for r in rows]}
    if qtype == 'multi':
        total = sum(r['count'] for r in rows)
        return {'type': qtype, 'answered': total, 'options': [{'value': r['_id'], 'count': r['count']} for r in rows]}
    if qtype == 'text':
        values = [str(r['answers']['value']) for r in rows]
        return {'type': qtype, 'answered': len(values), 'values': values}
    if qtype == 'number':
        if not rows:
            return {'type': qtype, 'answered': 0, 'avg': None, 'min': None, 'max': None}
        r = rows[0]
        return {
            'type': qtype,
            'answered': r['count'],
            'avg': round(r['avg'], 2) if r['avg'] is not None else None,
            'min': r['min'],
            'max': r['max'],
        }
    return {'type': qtype, 'answered': 0}


def bank_question_view(doc, user):
    versions = []
    for v in doc.get('versions', []):
        versions.append({
            'version': v['version'],
            'source_version': v.get('source_version'),
            'created_at': v.get('created_at').strftime('%Y-%m-%d %H:%M') if v.get('created_at') else None,
            'content': logic.version_payload(v),
        })
    current = doc['versions'][-1]
    owner = users.find_one({'_id': doc['owner_id']})
    return {
        'id': str(doc['_id']),
        'owner_id': str(doc['owner_id']),
        'owner_name': owner['username'] if owner else '',
        'mine': str(doc['owner_id']) == str(user['_id']),
        'shared': doc.get('shared', False),
        'display_title': doc.get('display_title'),
        'current_version': current['version'],
        'versions': versions,
        'source_question_id': str(doc['source_question_id']) if doc.get('source_question_id') else None,
        'created_at': doc.get('created_at').strftime('%Y-%m-%d %H:%M') if doc.get('created_at') else None,
        'updated_at': doc.get('updated_at').strftime('%Y-%m-%d %H:%M') if doc.get('updated_at') else None,
    }


def find_bank_question(qid, user):
    if not ObjectId.is_valid(qid):
        return None
    doc = question_bank.find_one({'_id': ObjectId(qid)})
    if not doc:
        return None
    if str(doc['owner_id']) != str(user['_id']) and not doc.get('shared'):
        return None
    return doc


def bank_version_content(doc, version):
    for v in doc.get('versions', []):
        if v['version'] == version:
            return logic.version_payload(v)
    return None


def resolve_bank_questions(questions, user):
    out = []
    for q in questions:
        qid = q.get('qid')
        stype = q.get('source_type', 'own')
        if stype == 'bank':
            bqid = q.get('bank_question_id')
            bver = q.get('bank_version')
            if not ObjectId.is_valid(str(bqid)):
                return None, '题库题引用无效'
            doc = question_bank.find_one({'_id': ObjectId(str(bqid))})
            if not doc:
                return None, '题库题不存在'
            if str(doc['owner_id']) != str(user['_id']) and not doc.get('shared'):
                return None, '题库题不可用（未共享）'
            content = bank_version_content(doc, bver)
            if content is None:
                return None, '题库题版本不存在'
            item = dict(content)
            item['qid'] = qid
            item['source_type'] = 'bank'
            item['bank_question_id'] = ObjectId(str(bqid))
            item['bank_version'] = bver
            item['jump_rules'] = q.get('jump_rules', [])
            out.append(item)
        else:
            item = dict(q)
            item.pop('bank_question_id', None)
            item.pop('bank_version', None)
            item['source_type'] = 'own'
            out.append(item)
    return out, ''


@app.route('/')
def index_page():
    return send_from_directory(app.static_folder, 'index.html')


@app.route('/dashboard')
def dashboard_page():
    return send_from_directory(app.static_folder, 'dashboard.html')


@app.route('/edit/')
@app.route('/edit/<survey_id>')
def edit_page(survey_id=''):
    return send_from_directory(app.static_folder, 'edit.html')


@app.route('/survey/<url_code>')
def fill_page(url_code):
    return send_from_directory(app.static_folder, 'fill.html')


@app.route('/stats/<survey_id>')
def stats_page(survey_id):
    return send_from_directory(app.static_folder, 'stats.html')


@app.route('/bank')
def bank_page():
    return send_from_directory(app.static_folder, 'question_bank.html')


@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json(silent=True) or {}
    username = str(data.get('username', '')).strip()
    password = str(data.get('password', ''))
    if not username or not password:
        return err('用户名和密码不能为空')
    if len(username) < 2 or len(username) > 20:
        return err('用户名长度需要在2到20个字符之间')
    if len(password) < 6:
        return err('密码长度至少6位')
    if users.find_one({'username': username}):
        return err('用户名已存在')
    result = users.insert_one({
        'username': username,
        'password_hash': generate_password_hash(password),
        'created_at': datetime.utcnow(),
    })
    session['user_id'] = str(result.inserted_id)
    return ok({'id': str(result.inserted_id), 'username': username})


@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json(silent=True) or {}
    username = str(data.get('username', '')).strip()
    password = str(data.get('password', ''))
    user = users.find_one({'username': username})
    if not user or not check_password_hash(user['password_hash'], password):
        return err('用户名或密码错误')
    session['user_id'] = str(user['_id'])
    return ok({'id': str(user['_id']), 'username': user['username']})


@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return ok()


@app.route('/api/me', methods=['GET'])
def me():
    user = current_user()
    if not user:
        return err('未登录', 401)
    return ok({'id': str(user['_id']), 'username': user['username']})


@app.route('/api/surveys', methods=['POST'])
def create_survey():
    user = current_user()
    if not user:
        return err('请先登录', 401)
    data = request.get_json(silent=True) or {}
    title = str(data.get('title', '')).strip()
    if not title:
        return err('问卷标题不能为空')
    doc = {
        'owner_id': user['_id'],
        'title': title,
        'description': str(data.get('description', '')).strip(),
        'allow_anonymous': bool(data.get('allow_anonymous', False)),
        'allow_multi_submit': bool(data.get('allow_multi_submit', False)),
        'status': 'draft',
        'deadline': parse_deadline(data.get('deadline')),
        'url_code': gen_url_code(),
        'questions': [],
        'created_at': datetime.utcnow(),
        'updated_at': datetime.utcnow(),
        'published_at': None,
        'closed_at': None,
    }
    result = surveys.insert_one(doc)
    doc['_id'] = result.inserted_id
    return ok(survey_view(doc))


@app.route('/api/surveys', methods=['GET'])
def list_surveys():
    user = current_user()
    if not user:
        return err('请先登录', 401)
    docs = surveys.find({'owner_id': user['_id']}).sort('updated_at', -1)
    return ok([survey_view(d) for d in docs])


@app.route('/api/surveys/code/<url_code>', methods=['GET'])
def get_survey_by_code(url_code):
    doc = surveys.find_one({'url_code': url_code})
    if not doc:
        return err('问卷不存在或链接错误', 404)
    if doc['status'] != 'published':
        return err('问卷不存在或已关闭', 404)
    if doc.get('deadline') and doc['deadline'] < datetime.utcnow():
        return err('问卷已过截止时间', 404)
    user = current_user()
    if not doc['allow_anonymous'] and not user:
        return err('该问卷需要登录后填写', 401)
    return ok(survey_fill_view(doc))


@app.route('/api/surveys/<sid>', methods=['GET'])
def get_survey(sid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_own_survey(sid, user)
    if not doc:
        return err('问卷不存在', 404)
    return ok(survey_view(doc))


@app.route('/api/surveys/<sid>', methods=['PUT'])
def update_survey(sid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_own_survey(sid, user)
    if not doc:
        return err('问卷不存在', 404)
    if doc['status'] != 'draft':
        return err('只有草稿状态的问卷可以编辑')
    data = request.get_json(silent=True) or {}
    title = str(data.get('title', '')).strip()
    if not title:
        return err('问卷标题不能为空')
    questions = data.get('questions', [])
    okq, msg = logic.validate_questions(questions)
    if not okq:
        return err(msg)
    resolved, msg = resolve_bank_questions(questions, user)
    if resolved is None:
        return err(msg)
    patch = {
        'title': title,
        'description': str(data.get('description', '')).strip(),
        'allow_anonymous': bool(data.get('allow_anonymous', False)),
        'allow_multi_submit': bool(data.get('allow_multi_submit', False)),
        'deadline': parse_deadline(data.get('deadline')),
        'questions': resolved,
        'updated_at': datetime.utcnow(),
    }
    surveys.update_one({'_id': ObjectId(sid)}, {'$set': patch})
    updated = surveys.find_one({'_id': ObjectId(sid)})
    return ok(survey_view(updated))


@app.route('/api/surveys/<sid>/publish', methods=['POST'])
def publish_survey(sid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_own_survey(sid, user)
    if not doc:
        return err('问卷不存在', 404)
    if not doc['questions']:
        return err('问卷还没有题目，无法发布')
    now = datetime.utcnow()
    surveys.update_one({'_id': doc['_id']}, {'$set': {'status': 'published', 'published_at': now, 'updated_at': now}})
    return ok(survey_view(surveys.find_one({'_id': doc['_id']})))


@app.route('/api/surveys/<sid>/close', methods=['POST'])
def close_survey(sid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_own_survey(sid, user)
    if not doc:
        return err('问卷不存在', 404)
    now = datetime.utcnow()
    surveys.update_one({'_id': doc['_id']}, {'$set': {'status': 'closed', 'closed_at': now, 'updated_at': now}})
    return ok(survey_view(surveys.find_one({'_id': doc['_id']})))


@app.route('/api/respond/<url_code>/answer', methods=['POST'])
def answer_question(url_code):
    survey = find_published_survey(url_code)
    if not survey:
        return err('问卷不存在、未发布、已关闭或已过截止时间', 404)
    user = current_user()
    if not survey['allow_anonymous'] and not user:
        return err('该问卷需要登录后填写', 401)
    data = request.get_json(silent=True) or {}
    qid = str(data.get('qid', ''))
    value = data.get('value')
    answered = data.get('answered') or []
    questions = survey['questions']
    idx = logic.question_index(questions, qid)
    if idx is None:
        return err('题目不存在', 404)
    q = questions[idx]
    okv, msg = logic.validate_answer(q, value)
    if not okv:
        return err(msg)
    next_qid = logic.next_question(questions, set(answered), idx, value)
    return ok({'next_qid': next_qid})


@app.route('/api/respond/<url_code>/submit', methods=['POST'])
def submit_response(url_code):
    survey = find_published_survey(url_code)
    if not survey:
        return err('问卷不存在、未发布、已关闭或已过截止时间', 404)
    user = current_user()
    if not survey['allow_anonymous'] and not user:
        return err('该问卷需要登录后填写', 401)
    data = request.get_json(silent=True) or {}
    answers = data.get('answers')
    if not isinstance(answers, list):
        return err('提交数据格式错误')
    normalized = []
    for a in answers:
        v = a.get('value')
        if isinstance(v, str) and not v.strip():
            v = None
        normalized.append({'qid': a.get('qid'), 'value': v})
    oksub, msg = logic.validate_submission(survey['questions'], normalized)
    if not oksub:
        return err(msg)
    if user and not survey['allow_multi_submit']:
        exists = responses.find_one({'survey_id': survey['_id'], 'user_id': user['_id']})
        if exists:
            return err('你已经填写过这份问卷')
    result = responses.insert_one({
        'survey_id': survey['_id'],
        'user_id': user['_id'] if user else None,
        'answers': normalized,
        'submitted_at': datetime.utcnow(),
    })
    return ok({'id': str(result.inserted_id)})


@app.route('/api/surveys/<sid>/stats', methods=['GET'])
def survey_stats(sid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_own_survey(sid, user)
    if not doc:
        return err('问卷不存在', 404)
    oid = doc['_id']
    total = responses.count_documents({'survey_id': oid})
    result = {'total_submits': total, 'questions': {}}
    for q in doc['questions']:
        result['questions'][q['qid']] = single_question_stats(oid, q)
    return ok(result)


@app.route('/api/surveys/<sid>/stats/<qid>', methods=['GET'])
def question_stats(sid, qid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_own_survey(sid, user)
    if not doc:
        return err('问卷不存在', 404)
    q = None
    for item in doc['questions']:
        if item['qid'] == qid:
            q = item
            break
    if not q:
        return err('题目不存在', 404)
    return ok(single_question_stats(doc['_id'], q))


@app.route('/api/questions', methods=['POST'])
def create_bank_question():
    user = current_user()
    if not user:
        return err('请先登录', 401)
    data = request.get_json(silent=True) or {}
    okq, msg = logic.validate_question_def(data)
    if not okq:
        return err(msg)
    now = datetime.utcnow()
    version = logic.question_payload(data)
    version['version'] = 1
    version['source_version'] = None
    version['created_at'] = now
    doc = {
        'owner_id': user['_id'],
        'shared': bool(data.get('shared', False)),
        'display_title': version['title'],
        'versions': [version],
        'created_at': now,
        'updated_at': now,
    }
    result = question_bank.insert_one(doc)
    doc['_id'] = result.inserted_id
    return ok(bank_question_view(doc, user))


@app.route('/api/questions', methods=['GET'])
def list_bank_questions():
    user = current_user()
    if not user:
        return err('请先登录', 401)
    scope = request.args.get('scope', 'mine')
    if scope == 'shared':
        docs = question_bank.find({'shared': True, 'owner_id': {'$ne': user['_id']}}).sort('updated_at', -1)
    elif scope == 'all':
        docs = question_bank.find({'$or': [{'owner_id': user['_id']}, {'shared': True}]}).sort('updated_at', -1)
    else:
        docs = question_bank.find({'owner_id': user['_id']}).sort('updated_at', -1)
    return ok([bank_question_view(d, user) for d in docs])


@app.route('/api/questions/<qid>', methods=['GET'])
def get_bank_question(qid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_bank_question(qid, user)
    if not doc:
        return err('题目不存在或无权访问', 404)
    return ok(bank_question_view(doc, user))


@app.route('/api/questions/<qid>', methods=['PUT'])
def update_bank_question(qid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_bank_question(qid, user)
    if not doc or str(doc['owner_id']) != str(user['_id']):
        return err('题目不存在或无权修改', 404)
    data = request.get_json(silent=True) or {}
    okq, msg = logic.validate_question_def(data)
    if not okq:
        return err(msg)
    now = datetime.utcnow()
    last = doc['versions'][-1]
    version = logic.question_payload(data)
    version['version'] = last['version'] + 1
    version['source_version'] = last['version']
    version['created_at'] = now
    question_bank.update_one({'_id': doc['_id']}, {
        '$push': {'versions': version},
        '$set': {'display_title': version['title'], 'updated_at': now},
    })
    return ok(bank_question_view(question_bank.find_one({'_id': doc['_id']}), user))


@app.route('/api/questions/<qid>/revert', methods=['POST'])
def revert_bank_question(qid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_bank_question(qid, user)
    if not doc or str(doc['owner_id']) != str(user['_id']):
        return err('题目不存在或无权修改', 404)
    data = request.get_json(silent=True) or {}
    ver = data.get('version')
    content = bank_version_content(doc, ver)
    if content is None:
        return err('版本不存在')
    now = datetime.utcnow()
    last = doc['versions'][-1]
    version = dict(content)
    version['version'] = last['version'] + 1
    version['source_version'] = ver
    version['created_at'] = now
    question_bank.update_one({'_id': doc['_id']}, {
        '$push': {'versions': version},
        '$set': {'display_title': version['title'], 'updated_at': now},
    })
    return ok(bank_question_view(question_bank.find_one({'_id': doc['_id']}), user))


@app.route('/api/questions/<qid>/clone', methods=['POST'])
def clone_bank_question(qid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_bank_question(qid, user)
    if not doc:
        return err('题目不存在或无权访问', 404)
    now = datetime.utcnow()
    current = doc['versions'][-1]
    version = logic.version_payload(current)
    version['version'] = 1
    version['source_version'] = current['version']
    version['created_at'] = now
    new_doc = {
        'owner_id': user['_id'],
        'shared': False,
        'display_title': version['title'],
        'source_question_id': doc['_id'],
        'versions': [version],
        'created_at': now,
        'updated_at': now,
    }
    result = question_bank.insert_one(new_doc)
    new_doc['_id'] = result.inserted_id
    return ok(bank_question_view(new_doc, user))


@app.route('/api/questions/<qid>/share', methods=['POST'])
def share_bank_question(qid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_bank_question(qid, user)
    if not doc or str(doc['owner_id']) != str(user['_id']):
        return err('题目不存在或无权修改', 404)
    data = request.get_json(silent=True) or {}
    shared = bool(data.get('shared', False))
    question_bank.update_one({'_id': doc['_id']}, {'$set': {'shared': shared, 'updated_at': datetime.utcnow()}})
    return ok(bank_question_view(question_bank.find_one({'_id': doc['_id']}), user))


def bank_usage(doc):
    oid = doc['_id']
    rows = list(surveys.aggregate([
        {'$match': {'questions.bank_question_id': oid}},
        {'$unwind': '$questions'},
        {'$match': {'questions.bank_question_id': oid}},
        {'$project': {
            'title': 1,
            'status': 1,
            'qid': '$questions.qid',
            'bank_version': '$questions.bank_version',
            'qtype': '$questions.type',
        }},
    ]))
    return rows


@app.route('/api/questions/<qid>/usage', methods=['GET'])
def bank_question_usage(qid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_bank_question(qid, user)
    if not doc:
        return err('题目不存在或无权访问', 404)
    rows = bank_usage(doc)
    return ok([{
        'survey_id': str(r['_id']),
        'title': r.get('title'),
        'status': r.get('status'),
        'qid': r.get('qid'),
        'bank_version': r.get('bank_version'),
        'qtype': r.get('qtype'),
    } for r in rows])


@app.route('/api/questions/<qid>/stats', methods=['GET'])
def bank_question_stats(qid):
    user = current_user()
    if not user:
        return err('请先登录', 401)
    doc = find_bank_question(qid, user)
    if not doc:
        return err('题目不存在或无权访问', 404)
    rows = bank_usage(doc)
    if not rows:
        return ok({'answered': 0, 'usage_count': 0, 'surveys': [], 'result': None})
    qtype = doc['versions'][-1]['type']
    match = {'$or': [{'survey_id': r['_id'], 'answers.qid': r['qid']} for r in rows]}
    stats_rows = list(responses.aggregate(logic.stats_pipeline(match, qtype)))
    if qtype == 'single':
        total = sum(r['count'] for r in stats_rows)
        result = {'type': qtype, 'answered': total, 'options': [{'value': r['_id'], 'count': r['count']} for r in stats_rows]}
    elif qtype == 'multi':
        total = sum(r['count'] for r in stats_rows)
        result = {'type': qtype, 'answered': total, 'options': [{'value': r['_id'], 'count': r['count']} for r in stats_rows]}
    elif qtype == 'text':
        values = [str(r['answers']['value']) for r in stats_rows]
        result = {'type': qtype, 'answered': len(values), 'values': values}
    elif qtype == 'number':
        if not stats_rows:
            result = {'type': qtype, 'answered': 0, 'avg': None, 'min': None, 'max': None}
        else:
            r = stats_rows[0]
            result = {
                'type': qtype,
                'answered': r['count'],
                'avg': round(r['avg'], 2) if r['avg'] is not None else None,
                'min': r['min'],
                'max': r['max'],
            }
    else:
        result = {'type': qtype, 'answered': 0}
    surveys_used = [{
        'survey_id': str(r['_id']),
        'title': r.get('title'),
        'status': r.get('status'),
        'qid': r.get('qid'),
        'bank_version': r.get('bank_version'),
    } for r in rows]
    return ok({'answered': result['answered'], 'usage_count': len(rows), 'surveys': surveys_used, 'result': result})


if __name__ == '__main__':
    init_db()
    app.run(host='127.0.0.1', port=5000, debug=False)
