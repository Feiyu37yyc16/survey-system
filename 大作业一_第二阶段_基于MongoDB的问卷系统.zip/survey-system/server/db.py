from pymongo import MongoClient
from config import MONGO_URI, MONGO_DB

client = MongoClient(MONGO_URI)
db = client[MONGO_DB]
users = db.users
surveys = db.surveys
responses = db.responses
question_bank = db.question_bank


def init_db():
    users.create_index('username', unique=True)
    surveys.create_index('owner_id')
    surveys.create_index('url_code', unique=True)
    surveys.create_index([('status', 1), ('published_at', -1)])
    responses.create_index([('survey_id', 1), ('submitted_at', -1)])
    responses.create_index([('survey_id', 1), ('user_id', 1)])
    question_bank.create_index('owner_id')
    question_bank.create_index([('shared', 1), ('updated_at', -1)])
