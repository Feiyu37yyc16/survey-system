import os
os.environ['MONGO_DB'] = 'survey_system_test'

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'server'))

from bson import ObjectId
from app import app
from db import db, responses

client_a = app.test_client()
client_b = app.test_client()
client_c = app.test_client()

RESULTS = []

MAIN_SID = None
MAIN_CODE = None
ANON_SID = None
ANON_CODE = None
EXPIRE_CODE = None
MULTI_CODE = None

MAIN_QUESTIONS = [
    {
        'qid': 'q1', 'type': 'single', 'title': '你的性别', 'required': True,
        'options': ['男', '女', '其他'], 'jump_rules': [
            {'condition': {'op': 'eq', 'value': '女'}, 'target': 'q3'}
        ]
    },
    {
        'qid': 'q2', 'type': 'multi', 'title': '你喜欢的水果', 'required': True,
        'options': ['苹果', '香蕉', '西瓜', '葡萄'],
        'min_choices': 2, 'max_choices': 3, 'jump_rules': [
            {'condition': {'op': 'contains', 'value': '苹果'}, 'target': 'q4'}
        ]
    },
    {
        'qid': 'q3', 'type': 'text', 'title': '你的职业', 'required': False,
        'min_length': 2, 'max_length': 50, 'jump_rules': []
    },
    {
        'qid': 'q4', 'type': 'number', 'title': '你的年龄', 'required': True,
        'min_value': 0, 'max_value': 120, 'integer_only': True, 'jump_rules': [
            {'condition': {'op': 'gte', 'value': 18}, 'target': 'q6'}
        ]
    },
    {
        'qid': 'q5', 'type': 'number', 'title': '手机号后四位', 'required': False,
        'integer_only': True, 'jump_rules': []
    },
    {
        'qid': 'q6', 'type': 'single', 'title': '整体满意度', 'required': True,
        'options': ['满意', '一般', '不满意'], 'jump_rules': []
    }
]


def post(client, path, body):
    return client.open(path, method='POST', json=body)


def put(client, path, body):
    return client.open(path, method='PUT', json=body)


def get(client, path):
    return client.open(path, method='GET')


def body(resp):
    return resp.get_json()


def record(name, ok, input_desc, expect, actual):
    RESULTS.append({
        'name': name,
        'ok': ok,
        'input': input_desc,
        'expect': expect,
        'actual': actual,
    })
    print('[%s] %s' % ('PASS' if ok else 'FAIL', name))


def register_user(client, username, password):
    resp = post(client, '/api/register', {'username': username, 'password': password})
    return resp.status_code, body(resp)


def create_and_publish(client, title, questions, extra=None):
    extra = extra or {}
    payload = {'title': title}
    if extra:
        payload.update(extra)
    resp = post(client, '/api/surveys', payload)
    sid = body(resp)['data']['id']
    put(client, '/api/surveys/' + sid, {
        'title': title,
        'description': '',
        'allow_anonymous': bool(extra.get('allow_anonymous', False)),
        'allow_multi_submit': bool(extra.get('allow_multi_submit', False)),
        'deadline': extra.get('deadline'),
        'questions': questions,
    })
    post(client, '/api/surveys/' + sid + '/publish', None)
    info = get(client, '/api/surveys/' + sid)
    return sid, body(info)['data']['url_code']


class TestSurveySystem(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        db.client.drop_database('survey_system_test')
        register_user(client_a, 'alice', 'alice123')
        register_user(client_b, 'bob', 'bob123456')
        global MAIN_SID, MAIN_CODE
        MAIN_SID, MAIN_CODE = create_and_publish(client_a, '用户满意度调查', MAIN_QUESTIONS)
        global ANON_SID, ANON_CODE
        anon_sid, anon_code = create_and_publish(client_a, '匿名反馈', [
            {'qid': 'a1', 'type': 'single', 'title': '整体评价', 'required': True, 'options': ['好', '差'], 'jump_rules': []}
        ], {'allow_anonymous': True})
        ANON_SID = anon_sid
        ANON_CODE = anon_code
        global EXPIRE_CODE
        expire_sid, expire_code = create_and_publish(client_a, '过期问卷', [
            {'qid': 'e1', 'type': 'text', 'title': '内容', 'required': False, 'jump_rules': []}
        ], {'deadline': '2020-01-01T00:00'})
        EXPIRE_CODE = expire_code
        global MULTI_CODE
        multi_sid, multi_code = create_and_publish(client_a, '可多次填写', [
            {'qid': 'm1', 'type': 'text', 'title': '内容', 'required': True, 'jump_rules': []}
        ], {'allow_multi_submit': True})
        MULTI_CODE = multi_code

    def test_01_auth(self):
        resp = post(client_a, '/api/register', {'username': 'alice', 'password': 'alice123'})
        data = body(resp)
        ok = resp.status_code == 400 and data['code'] == 1
        record('重复注册被拒绝', ok, 'POST /api/register alice/alice123', '报错：用户名已存在', data.get('message'))

        resp = post(client_a, '/api/login', {'username': 'alice', 'password': 'wrong'})
        data = body(resp)
        ok = resp.status_code == 400 and data['code'] == 1
        record('错误密码登录被拒绝', ok, 'POST /api/login alice/wrong', '报错：用户名或密码错误', data.get('message'))

        resp = get(client_a, '/api/me')
        ok = resp.status_code == 200 and body(resp)['data']['username'] == 'alice'
        record('登录态查询当前用户', ok, 'GET /api/me', '返回 alice', body(resp).get('data'))

    def test_02_create_survey(self):
        resp = post(client_a, '/api/surveys', {'title': '临时问卷'})
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['status'] == 'draft' and data['data']['url_code']
        record('创建问卷生成草稿与短码', ok, 'POST /api/surveys title=临时问卷', '返回 draft 状态和 url_code', data.get('data'))

        resp = get(client_a, '/api/surveys')
        data = body(resp)
        ok = resp.status_code == 200 and isinstance(data['data'], list) and len(data['data']) >= 1
        record('查看问卷列表', ok, 'GET /api/surveys', '返回本人问卷数组', '共 %d 份' % len(data['data']))

    def test_03_illegal_jump_config(self):
        resp = post(client_a, '/api/surveys', {'title': '跳转测试草稿'})
        sid = body(resp)['data']['id']
        questions = [
            {'qid': 'q1', 'type': 'single', 'title': '题目一', 'required': True,
             'options': ['A', 'B'], 'jump_rules': [{'condition': {'op': 'eq', 'value': 'A'}, 'target': 'ghost'}]},
            {'qid': 'q2', 'type': 'single', 'title': '题目二', 'required': True,
             'options': ['A', 'B'], 'jump_rules': []}
        ]
        resp = put(client_a, '/api/surveys/' + sid, {
            'title': '跳转测试草稿', 'description': '', 'allow_anonymous': False,
            'allow_multi_submit': False, 'deadline': None, 'questions': questions
        })
        ok = resp.status_code == 400 and body(resp).get('message') == '第1题：跳转目标不存在'
        record('跳转目标不存在被拒绝', ok, 'PUT 设置跳转目标 ghost', '报错：跳转目标不存在', body(resp).get('message'))

        questions[0]['jump_rules'] = [{'condition': {'op': 'eq', 'value': 'A'}, 'target': 'q1'}]
        resp = put(client_a, '/api/surveys/' + sid, {
            'title': '跳转测试草稿', 'description': '', 'allow_anonymous': False,
            'allow_multi_submit': False, 'deadline': None, 'questions': questions
        })
        ok = resp.status_code == 400 and body(resp).get('message') == '第1题：跳转目标必须在本题之后'
        record('跳转目标不允许向前被拒绝', ok, 'PUT 设置跳转目标 q1（指向自身）', '报错：跳转目标必须在本题之后', body(resp).get('message'))

    def test_04_validation(self):
        cases = [
            ('q1', None, '单选必答未选', '请选择一个选项'),
            ('q2', ['香蕉'], '多选少于最少数量', '本题至少选择2个选项'),
            ('q2', ['苹果', '香蕉', '西瓜', '葡萄'], '多选超过最多数量', '本题最多选择3个选项'),
            ('q3', 'a', '文本少于最少字数', '字数不能少于2'),
            ('q4', 150, '数字超过最大值', '数值不能大于120'),
            ('q4', 18.5, '数字非整数', '必须是整数'),
        ]
        for qid, value, desc, expect in cases:
            resp = post(client_b, '/api/respond/' + MAIN_CODE + '/answer', {'qid': qid, 'value': value, 'answered': []})
            data = body(resp)
            ok = resp.status_code == 400 and data.get('message') == expect
            record('答案校验：' + desc, ok, '%s=%s' % (qid, value), expect, data.get('message'))

    def test_05_jump_single(self):
        resp = post(client_b, '/api/respond/' + MAIN_CODE + '/answer', {'qid': 'q1', 'value': '女', 'answered': []})
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['next_qid'] == 'q3'
        record('单选跳转（选女跳到q3）', ok, 'q1=女, answered=[]', 'next_qid=q3', data.get('data'))

        resp = post(client_b, '/api/respond/' + MAIN_CODE + '/answer', {'qid': 'q1', 'value': '男', 'answered': []})
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['next_qid'] == 'q2'
        record('单选无规则按顺序到q2', ok, 'q1=男, answered=[]', 'next_qid=q2', data.get('data'))

    def test_06_jump_multi(self):
        resp = post(client_b, '/api/respond/' + MAIN_CODE + '/answer', {'qid': 'q2', 'value': ['苹果', '香蕉'], 'answered': ['q1']})
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['next_qid'] == 'q4'
        record('多选跳转（包含苹果跳到q4）', ok, 'q2=[苹果,香蕉]', 'next_qid=q4', data.get('data'))

        resp = post(client_b, '/api/respond/' + MAIN_CODE + '/answer', {'qid': 'q2', 'value': ['香蕉', '西瓜'], 'answered': ['q1']})
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['next_qid'] == 'q3'
        record('多选无规则按顺序到q3', ok, 'q2=[香蕉,西瓜]', 'next_qid=q3', data.get('data'))

    def test_07_jump_number(self):
        resp = post(client_b, '/api/respond/' + MAIN_CODE + '/answer', {'qid': 'q4', 'value': 25, 'answered': ['q1', 'q2', 'q3']})
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['next_qid'] == 'q6'
        record('数字跳转（年龄25>=18跳到q6）', ok, 'q4=25', 'next_qid=q6', data.get('data'))

        resp = post(client_b, '/api/respond/' + MAIN_CODE + '/answer', {'qid': 'q4', 'value': 15, 'answered': ['q1', 'q3']})
        data = body(resp)
        ok = resp.status_code == 200 and data['data']['next_qid'] == 'q5'
        record('数字无规则按顺序到q5', ok, 'q4=15', 'next_qid=q5', data.get('data'))

    def test_08_submit_basic(self):
        answers_a = [
            {'qid': 'q1', 'value': '男'},
            {'qid': 'q2', 'value': ['香蕉', '西瓜']},
            {'qid': 'q3', 'value': '程序员'},
            {'qid': 'q4', 'value': 25},
            {'qid': 'q6', 'value': '满意'},
        ]
        resp = post(client_b, '/api/respond/' + MAIN_CODE + '/submit', {'answers': answers_a})
        ok = resp.status_code == 200 and body(resp)['data'].get('id')
        record('提交问卷（路径A）', ok, 'answers=5条回答', '返回提交记录id', body(resp).get('data'))

        answers_b = [
            {'qid': 'q1', 'value': '女'},
            {'qid': 'q3', 'value': '教师'},
            {'qid': 'q4', 'value': 15},
            {'qid': 'q5', 'value': 1234},
            {'qid': 'q6', 'value': '一般'},
        ]
        resp = post(client_a, '/api/respond/' + MAIN_CODE + '/submit', {'answers': answers_b})
        ok = resp.status_code == 200 and body(resp)['data'].get('id')
        record('提交问卷（路径B：跳过q2）', ok, 'answers=5条回答（无q2）', '返回提交记录id', body(resp).get('data'))

        resp = post(client_b, '/api/respond/' + MAIN_CODE + '/submit', {'answers': answers_a})
        ok = resp.status_code == 400
        record('不允许重复提交被拒绝', ok, 'bob 再次提交', '报错：你已经填写过这份问卷', body(resp).get('message'))

    def test_09_submit_missing_answer(self):
        resp = post(client_b, '/api/respond/' + MAIN_CODE + '/submit', {'answers': [{'qid': 'q1', 'value': '男'}]})
        ok = resp.status_code == 400
        record('缺少必答题被拒绝', ok, '只提交q1', '报错：缺少题目q2的回答', body(resp).get('message'))

    def test_10_anonymous(self):
        resp = get(client_c, '/api/surveys/code/' + MAIN_CODE)
        ok = resp.status_code == 401
        record('未登录不能填非匿名问卷', ok, 'GET code（未登录）', '401 需要登录', body(resp).get('message'))

        resp = get(client_c, '/api/surveys/code/' + ANON_CODE)
        ok = resp.status_code == 200
        record('未登录可以填匿名问卷', ok, 'GET code（匿名问卷）', '200 返回题目', 'status=%d' % resp.status_code)

        resp = post(client_c, '/api/respond/' + ANON_CODE + '/answer', {'qid': 'a1', 'value': '好', 'answered': []})
        ok = resp.status_code == 200 and body(resp)['data']['next_qid'] is None
        record('匿名回答通过', ok, 'a1=好', 'next_qid=None', body(resp).get('data'))

        resp = post(client_c, '/api/respond/' + ANON_CODE + '/submit', {'answers': [{'qid': 'a1', 'value': '好'}]})
        ok = resp.status_code == 200
        record('匿名提交成功', ok, 'submit a1=好', '返回提交记录id', body(resp).get('data'))

        rec = responses.find_one({'survey_id': ObjectId(ANON_SID)})
        ok = rec is not None and rec['user_id'] is None
        record('匿名提交不记录用户', ok, '查数据库 response', 'user_id 为空', rec and rec['user_id'])

    def test_11_multi_submit(self):
        answers = [{'qid': 'm1', 'value': '第一次'}]
        resp1 = post(client_b, '/api/respond/' + MULTI_CODE + '/submit', {'answers': answers})
        answers2 = [{'qid': 'm1', 'value': '第二次'}]
        resp2 = post(client_b, '/api/respond/' + MULTI_CODE + '/submit', {'answers': answers2})
        ok = resp1.status_code == 200 and resp2.status_code == 200
        record('允许同一用户多次填写', ok, 'bob 连续提交两次', '两次都成功', 'status=%d,%d' % (resp1.status_code, resp2.status_code))

    def test_12_deadline_and_close(self):
        resp = get(client_b, '/api/surveys/code/' + EXPIRE_CODE)
        ok = resp.status_code == 404
        record('过期问卷不可填写', ok, 'GET code（截止时间已过）', '404 报错', body(resp).get('message'))

        tmp, tmp_code = create_and_publish(client_a, '待关闭问卷', [
            {'qid': 'c1', 'type': 'text', 'title': '内容', 'required': True, 'jump_rules': []}
        ])
        post(client_a, '/api/surveys/' + tmp + '/close', None)
        resp = get(client_b, '/api/surveys/code/' + tmp_code)
        ok = resp.status_code == 404
        record('关闭问卷不可填写', ok, 'close 后 GET code', '404 报错', body(resp).get('message'))

    def test_13_stats(self):
        resp = get(client_a, '/api/surveys/' + MAIN_SID + '/stats')
        data = body(resp)['data']
        q1 = data['questions']['q1']
        ok1 = data['total_submits'] == 2
        ok2 = q1['answered'] == 2 and {o['value']: o['count'] for o in q1['options']} == {'男': 1, '女': 1}
        record('单选题统计', ok1 and ok2, 'GET stats', 'total=2, 男1女1', data)

        q2 = data['questions']['q2']
        ok = q2['answered'] == 2 and {o['value']: o['count'] for o in q2['options']} == {'香蕉': 1, '西瓜': 1}
        record('多选题统计', ok, 'GET stats q2', '香蕉1 西瓜1', q2)

        q3 = data['questions']['q3']
        ok = q3['answered'] == 2 and '教师' in q3['values'] and '程序员' in q3['values']
        record('文本题统计', ok, 'GET stats q3', '包含教师和程序员', q3)

        q4 = data['questions']['q4']
        ok = q4['answered'] == 2 and q4['avg'] == 20.0 and q4['min'] == 15 and q4['max'] == 25
        record('数字题统计（平均值）', ok, 'GET stats q4', 'avg=20 min=15 max=25', q4)

        q5 = data['questions']['q5']
        ok = q5['answered'] == 1 and q5['min'] == 1234
        record('被跳过题目统计', ok, 'GET stats q5', '仅1人回答，值为1234', q5)

        resp = get(client_a, '/api/surveys/' + MAIN_SID + '/stats/q1')
        q1s = body(resp)['data']
        ok = q1s['answered'] == 2
        record('单题统计接口', ok, 'GET stats/q1', 'answered=2', q1s)


def main():
    suite = unittest.TestLoader().loadTestsFromTestCase(TestSurveySystem)
    runner = unittest.TextTestRunner(verbosity=0)
    runner.run(suite)
    report_path = Path(__file__).resolve().parent / '测试报告_自动化.md'
    lines = ['# 自动化测试报告', '', '运行时间：见下方用例顺序', '', '| 用例 | 结果 | 输入 | 期望输出 | 实际输出 |', '|---|---|---|---|---|']
    for r in RESULTS:
        lines.append('| %s | %s | %s | %s | %s |' % (r['name'], '通过' if r['ok'] else '失败', r['input'], r['expect'], r['actual']))
    passed = sum(1 for r in RESULTS if r['ok'])
    lines.append('')
    lines.append('共 %d 个用例，通过 %d 个，失败 %d 个。' % (len(RESULTS), passed, len(RESULTS) - passed))
    report_path.write_text('\n'.join(lines), encoding='utf-8')
    print('测试报告已写入：%s' % report_path)
    if passed < len(RESULTS):
        sys.exit(1)


if __name__ == '__main__':
    main()
