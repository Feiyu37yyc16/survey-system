# 03 API 说明

接口统一返回 JSON：

```json
{ "code": 0, "data": { ... } }        // 成功
{ "code": 1, "message": "错误信息" }  // 失败
```

HTTP 状态码：200 成功；400 参数或业务校验失败；401 未登录；404 资源不存在。

会话通过 Cookie 维持：注册或登录成功后服务端写入签名 Cookie，后续请求自动携带。同一问卷的"只能看到自己创建的问卷"在服务端按会话中的用户 ID 校验。

## 1. 认证接口

### 1.1 注册

`POST /api/register`

请求：

```json
{ "username": "alice", "password": "alice123" }
```

返回：

```json
{ "code": 0, "data": { "id": "668f...", "username": "alice" } }
```

校验：用户名 2-20 个字符且唯一；密码至少 6 位。注册成功后自动登录。

### 1.2 登录

`POST /api/login`

请求：

```json
{ "username": "alice", "password": "alice123" }
```

返回同上。用户名或密码错误返回 400。

### 1.3 退出

`POST /api/logout`，无参数，清空会话。

### 1.4 当前用户

`GET /api/me`，返回当前登录用户信息；未登录返回 401。

## 2. 问卷接口（需登录，仅本人问卷）

### 2.1 创建问卷

`POST /api/surveys`

请求：

```json
{ "title": "未命名问卷", "description": "", "allow_anonymous": false, "allow_multi_submit": false, "deadline": null }
```

返回新建的问卷对象，初始状态为 `draft`，并生成 `url_code` 短码。

### 2.2 问卷列表

`GET /api/surveys`

返回当前用户所有问卷，按更新时间倒序。

### 2.3 问卷详情

`GET /api/surveys/<id>`

返回问卷全部字段，包括题目数组和跳转规则。非本人问卷返回 404。

### 2.4 更新问卷（保存编辑）

`PUT /api/surveys/<id>`

请求：

```json
{
  "title": "用户满意度调查",
  "description": "感谢参与",
  "allow_anonymous": false,
  "allow_multi_submit": false,
  "deadline": "2026-12-31T23:59",
  "questions": [
    {
      "qid": "q1",
      "type": "single",
      "title": "你的性别",
      "required": true,
      "options": ["男", "女", "其他"],
      "jump_rules": [ { "condition": { "op": "eq", "value": "女" }, "target": "q3" } ]
    }
  ]
}
```

服务端校验：题型合法、选项非空且不重复、多选数量限制合法、文本字数限制合法、数值范围合法、跳转目标存在且在本题之后。校验失败返回 400 和具体错误位置（第几题）。只有 `draft` 状态的问卷可以编辑。

### 2.5 发布问卷

`POST /api/surveys/<id>/publish`

要求问卷至少有一道题。发布后状态变为 `published`，可以填写。

### 2.6 关闭问卷

`POST /api/surveys/<id>/close`

状态变为 `closed`，之后不可填写。

## 3. 填写接口

### 3.1 获取问卷（链接入口）

`GET /api/surveys/code/<url_code>`

返回标题、说明、是否匿名、题目列表（含各题限制条件，不含跳转规则之外的信息）。

状态检查：问卷必须是 `published` 且未过截止时间，否则 404；问卷不允许匿名填写时，未登录用户返回 401。

### 3.2 提交单题答案并获取下一题

`POST /api/respond/<url_code>/answer`

请求：

```json
{ "qid": "q1", "value": "女", "answered": ["q1"] }
```

`answered` 是本次填写中已经回答过的题目编号列表（不含当前题）。

处理流程：校验当前题答案是否符合规则 → 计算下一题（先看当前题有没有命中的跳转规则，命中则跳转目标，否则按顺序取下一道未回答的题）→ 返回：

```json
{ "code": 0, "data": { "next_qid": "q3" } }
```

没有下一题时 `next_qid` 为 null。校验失败返回 400 和错误信息。

### 3.3 提交整份问卷

`POST /api/respond/<url_code>/submit`

请求：

```json
{ "answers": [ { "qid": "q1", "value": "女" }, { "qid": "q3", "value": "教师" } ] }
```

服务端按题目顺序模拟一遍填写流程：检查每一道被访问到的题都有答案、答案合法、跳转路径一致，避免跳过前端直接提交非法数据。通过后保存一条 responses 记录。

限制：问卷不允许匿名时未登录用户不可提交；问卷未开启多次填写时，同一登录用户重复提交返回 400。

## 4. 统计接口（需登录，仅本人问卷）

### 4.1 整体统计

`GET /api/surveys/<id>/stats`

返回：

```json
{
  "code": 0,
  "data": {
    "total_submits": 2,
    "questions": {
      "q1": { "type": "single", "answered": 2, "options": [ { "value": "男", "count": 1 }, { "value": "女", "count": 1 } ] },
      "q2": { "type": "multi", "answered": 2, "options": [ { "value": "香蕉", "count": 1 }, { "value": "西瓜", "count": 1 } ] },
      "q3": { "type": "text", "answered": 2, "values": ["教师", "程序员"] },
      "q4": { "type": "number", "answered": 2, "avg": 20.0, "min": 15, "max": 25 }
    }
  }
}
```

说明：`total_submits` 是收到的填写总份数；`answered` 是实际回答了该题的人数；多选 `answered` 是所有被选择次数的合计；被跳过的题不出现在统计中（跳过意味着没回答）。

### 4.2 单题统计

`GET /api/surveys/<id>/stats/<qid>`

返回该题单独的统计，结构与整体统计中对应题目一致。
