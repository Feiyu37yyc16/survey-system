async function api(path, method, body) {
  const opts = { method: method || 'GET', headers: {} };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.code !== 0) {
    throw new Error(data.message || '请求失败');
  }
  return data.data;
}

async function checkLogin() {
  try {
    return await api('/api/me');
  } catch (e) {
    return null;
  }
}

async function logout() {
  await api('/api/logout', 'POST');
  location.href = '/';
}

function esc(s) {
  const div = document.createElement('div');
  div.textContent = s == null ? '' : String(s);
  return div.innerHTML;
}
