ALLOWED_OPS = {
    'single': ('eq',),
    'multi': ('contains',),
    'text': ('eq', 'contains'),
    'number': ('gt', 'gte', 'lt', 'lte', 'eq', 'between'),
}


def clean_options(q):
    options = q.get('options')
    if not isinstance(options, list):
        return []
    return [str(o).strip() for o in options if str(o).strip()]


def validate_question_def(q):
    qid = str(q.get('qid', '')).strip()
    qtype = q.get('type', '')
    title = str(q.get('title', '')).strip()
    if not qid or qtype not in ('single', 'multi', 'text', 'number') or not title:
        return False, '题目编号、类型和标题不能为空'
    if qtype in ('single', 'multi'):
        options = clean_options(q)
        if not options:
            return False, '选项不能为空'
        if len(set(options)) != len(options):
            return False, '选项不能重复'
        if qtype == 'multi':
            ec = q.get('exact_choices')
            if ec is not None and ec not in ('', 0):
                if not isinstance(ec, int) or ec < 1:
                    return False, '必须选择数必须是正整数'
                if ec > len(options):
                    return False, '必须选择数不能超过选项数'
            else:
                mc = q.get('max_choices')
                if isinstance(mc, int) and mc < 1:
                    return False, '最多选择数必须大于0'
                if isinstance(mc, int) and mc > len(options):
                    return False, '最多选择数不能超过选项数'
    if qtype == 'text':
        mn = q.get('min_length')
        mx = q.get('max_length')
        if isinstance(mn, int) and mn < 0:
            return False, '最少字数不能为负'
        if isinstance(mx, int) and mx < 1:
            return False, '最多字数必须大于0'
        if isinstance(mn, int) and isinstance(mx, int) and mn > mx:
            return False, '最少字数不能大于最多字数'
    if qtype == 'number':
        lo = q.get('min_value')
        hi = q.get('max_value')
        if isinstance(lo, (int, float)) and isinstance(hi, (int, float)) and lo > hi:
            return False, '最小值不能大于最大值'
    rules = q.get('jump_rules')
    if not isinstance(rules, list):
        return False, '跳转规则格式错误'
    options = clean_options(q)
    for r in rules:
        cond = r.get('condition')
        target = str(r.get('target', '')).strip()
        if not isinstance(cond, dict) or not target:
            return False, '跳转规则不完整'
        op = cond.get('op')
        if op not in ALLOWED_OPS.get(qtype, ()):
            return False, '该题型不支持此跳转条件'
        value = cond.get('value')
        if op == 'between':
            if not (isinstance(value, list) and len(value) == 2):
                return False, 'between 条件需要两个边界值'
        elif qtype in ('single', 'multi'):
            if value not in options:
                return False, '跳转条件中的选项不在选项列表中'
    return True, ''


def validate_questions(questions):
    if not isinstance(questions, list):
        return False, '题目格式错误'
    order = {}
    seen = set()
    for i, q in enumerate(questions):
        qid = str(q.get('qid', '')).strip()
        if not qid or qid in seen:
            return False, '第%d题：题目编号缺失或重复' % (i + 1)
        seen.add(qid)
        order[qid] = i
        ok, msg = validate_question_def(q)
        if not ok:
            return False, '第%d题：%s' % (i + 1, msg)
    for i, q in enumerate(questions):
        for r in q.get('jump_rules', []):
            target = str(r.get('target', '')).strip()
            if target not in order:
                return False, '第%d题：跳转目标不存在' % (i + 1)
            if order[target] <= i:
                return False, '第%d题：跳转目标必须在本题之后' % (i + 1)
    return True, ''


def validate_answer(q, value):
    if not q.get('required') and (value is None or value == '' or (isinstance(value, list) and not value)):
        return True, ''
    qtype = q.get('type')
    if qtype == 'single':
        if not isinstance(value, str) or not value.strip():
            return False, '请选择一个选项'
        if value.strip() not in clean_options(q):
            return False, '选项不在题目选项中'
        return True, ''
    if qtype == 'multi':
        if not isinstance(value, list):
            return False, '多选题需要选择数组'
        options = clean_options(q)
        for v in value:
            if v not in options:
                return False, '选项不在题目选项中'
        ec = q.get('exact_choices')
        if ec is not None and ec not in ('', 0):
            if len(value) != ec:
                return False, '本题必须选择%d个选项' % ec
        else:
            mn = q.get('min_choices')
            mx = q.get('max_choices')
            if isinstance(mn, int) and len(value) < mn:
                return False, '本题至少选择%d个选项' % mn
            if isinstance(mx, int) and len(value) > mx:
                return False, '本题最多选择%d个选项' % mx
        return True, ''
    if qtype == 'text':
        if not isinstance(value, str):
            return False, '填空题需要文本'
        text = value.strip()
        mn = q.get('min_length')
        mx = q.get('max_length')
        if isinstance(mn, int) and len(text) < mn:
            return False, '字数不能少于%d' % mn
        if isinstance(mx, int) and len(text) > mx:
            return False, '字数不能超过%d' % mx
        return True, ''
    if qtype == 'number':
        try:
            num = float(value)
        except (TypeError, ValueError):
            return False, '请输入有效数字'
        if q.get('integer_only') and not num.is_integer():
            return False, '必须是整数'
        if q.get('integer_only'):
            num = int(num)
        lo = q.get('min_value')
        hi = q.get('max_value')
        if isinstance(lo, (int, float)) and num < lo:
            return False, '数值不能小于%s' % lo
        if isinstance(hi, (int, float)) and num > hi:
            return False, '数值不能大于%s' % hi
        return True, ''
    return False, '未知题型'


def rule_hit(rule, qtype, value):
    cond = rule.get('condition', {})
    op = cond.get('op')
    v = cond.get('value')
    if qtype == 'single':
        return op == 'eq' and value.strip() == str(v).strip()
    if qtype == 'multi':
        return op == 'contains' and str(v).strip() in value
    if qtype == 'text':
        text = value.strip()
        if op == 'eq':
            return text == str(v).strip()
        if op == 'contains':
            return str(v).strip() in text
        return False
    if qtype == 'number':
        num = float(value)
        if op == 'gt':
            return num > float(v)
        if op == 'gte':
            return num >= float(v)
        if op == 'lt':
            return num < float(v)
        if op == 'lte':
            return num <= float(v)
        if op == 'eq':
            return num == float(v)
        if op == 'between':
            lo, hi = v
            return float(lo) <= num <= float(hi)
    return False


def question_index(questions, qid):
    for i, q in enumerate(questions):
        if q.get('qid') == qid:
            return i
    return None


def next_question(questions, answered, current_idx, current_value):
    n = len(questions)
    q = questions[current_idx]
    qtype = q.get('type')
    target = None
    for rule in q.get('jump_rules', []):
        if rule_hit(rule, qtype, current_value):
            target = str(rule.get('target', ''))
            break
    if target:
        t_idx = question_index(questions, target)
        if t_idx is not None and t_idx > current_idx:
            idx = t_idx
            while idx < n and questions[idx].get('qid') in answered:
                idx += 1
            if idx < n:
                return questions[idx].get('qid')
            return None
    idx = current_idx + 1
    while idx < n and questions[idx].get('qid') in answered:
        idx += 1
    if idx < n:
        return questions[idx].get('qid')
    return None


def validate_submission(questions, answers):
    if not isinstance(answers, list):
        return False, '提交数据格式错误'
    amap = {}
    for a in answers:
        qid = str(a.get('qid', ''))
        if not qid:
            return False, '回答缺少题目编号'
        amap[qid] = a.get('value')
    answered = set()
    idx = 0
    while idx < len(questions):
        q = questions[idx]
        qid = q.get('qid')
        if qid in answered:
            idx += 1
            continue
        if qid not in amap:
            return False, '缺少题目%s的回答' % qid
        value = amap[qid]
        ok, msg = validate_answer(q, value)
        if not ok:
            return False, '题目%s：%s' % (qid, msg)
        answered.add(qid)
        nxt = next_question(questions, answered, idx, value)
        if nxt is None:
            break
        idx = question_index(questions, nxt)
    return True, ''


def single_stats_pipeline(oid, qid, qtype):
    base = [
        {'$match': {'survey_id': oid}},
        {'$unwind': '$answers'},
        {'$match': {'answers.qid': qid}},
    ]
    if qtype in ('single', 'multi'):
        pipe = list(base)
        if qtype == 'single':
            pipe.append({'$match': {'answers.value': {'$ne': None}}})
        if qtype == 'multi':
            pipe.append({'$unwind': '$answers.value'})
        pipe += [
            {'$group': {'_id': '$answers.value', 'count': {'$sum': 1}}},
            {'$sort': {'count': -1}},
        ]
        return pipe
    if qtype == 'text':
        return base + [
            {'$sort': {'submitted_at': -1}},
            {'$limit': 500},
        ]
    if qtype == 'number':
        return base + [
            {'$group': {
                '_id': None,
                'count': {'$sum': 1},
                'avg': {'$avg': '$answers.value'},
                'min': {'$min': '$answers.value'},
                'max': {'$max': '$answers.value'},
            }},
        ]
    return []
