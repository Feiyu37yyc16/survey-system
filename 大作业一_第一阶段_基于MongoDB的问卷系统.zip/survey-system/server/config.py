import os

MONGO_URI = os.environ.get('MONGO_URI', 'mongodb://127.0.0.1:27017/')
MONGO_DB = os.environ.get('MONGO_DB', 'survey_system')
SECRET_KEY = os.environ.get('SECRET_KEY', 'survey-system-secret-2026')
URL_CODE_LEN = 8
