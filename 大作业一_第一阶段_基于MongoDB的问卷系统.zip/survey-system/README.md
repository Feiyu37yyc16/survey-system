# 基于 MongoDB 的问卷系统

一个简化版的在线问卷系统，功能类似问卷星或 Google Forms。用户注册登录后可以创建问卷、通过链接分发问卷、收集填写结果并查看统计。

## 技术栈

- 后端：Python 3 + Flask
- 数据库：MongoDB（pymongo）
- 前端：原生 HTML / CSS / JavaScript，由 Flask 直接伺服

## 环境要求

- Python 3.10 及以上
- MongoDB（本地实例，默认连接 `mongodb://127.0.0.1:27017/`）

## 安装与启动

```bash
# 1. 安装依赖
pip install -r server/requirements.txt

# 2. 启动 MongoDB（以本机为例）
mongod --dbpath <数据目录> --port 27017

# 3. 启动服务
cd server
python app.py
```

服务启动后访问 http://127.0.0.1:5000/ 。

配置项通过环境变量覆盖（默认值见 `server/config.py`）：

| 环境变量 | 说明 | 默认值 |
|---|---|---|
| MONGO_URI | MongoDB 连接串 | mongodb://127.0.0.1:27017/ |
| MONGO_DB | 数据库名 | survey_system |
| SECRET_KEY | 会话签名密钥 | 内置默认值（生产环境请修改） |

## 使用流程

1. 打开首页，注册账号并登录
2. 进入「我的问卷」，点击「新建问卷」，自动进入编辑页
3. 填写标题、说明，设置是否允许匿名填写、是否允许同一用户多次填写、截止时间
4. 添加题目：单选题、多选题、文本填空、数字填空，设置选项、必答、选择数量限制、字数限制、数值范围，以及跳转规则
5. 保存问卷，回到列表页点击「发布」
6. 复制问卷链接（形如 `/survey/xxxxxx`）发给填写人
7. 填写人登录后打开链接，按顺序回答，系统按规则自动跳转并校验输入
8. 创建者在列表页点「统计」，查看整体统计或某一道题的统计

## 目录结构

```
survey-system/
├── server/
│   ├── app.py              # Flask 应用与全部接口
│   ├── config.py           # 配置
│   ├── db.py               # MongoDB 连接与索引
│   ├── logic.py            # 校验、跳转、统计聚合逻辑
│   ├── requirements.txt    # Python 依赖
│   └── static/             # 前端页面
│       ├── index.html      # 登录/注册
│       ├── dashboard.html  # 问卷列表
│       ├── edit.html       # 问卷编辑
│       ├── fill.html       # 问卷填写
│       ├── stats.html      # 统计查看
│       ├── css/style.css
│       └── js/common.js
├── tests/
│   └── test_api.py         # 自动化 API 测试
├── docs/
│   ├── 01-系统说明.md
│   ├── 02-数据库设计.md
│   ├── 03-API说明.md
│   ├── 04-关键逻辑说明.md
│   └── 05-测试用例.md
└── report/
    └── 项目完成报告.md
```
